<?php $__env->startSection('content'); ?>
<div class=" d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
        <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5"><?php echo e($title); ?></h5>
                    <!--end::Page Title-->
                </div>
                <!--end::Page Heading-->
            </div>
            <!--end::Info-->

        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="p-6 flex-fill">
        <div class="card card-custom gutter-b">
            <div class="card-header align-content-center">
                <div class="card-title">
                    <?php echo e($training->name ?? ''); ?>

                </div>
                <div class="p-2">
                    <!--begin::Button-->
                    <a href="<?php echo e(route('trainings-manage')); ?>" class="btn btn-primary">
                        Back</a>
                    <!--end::Button-->
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-4 sticky-top">
                        <div class="form-group">
                            <div class="videoswrp">
                                <?php if(!empty($videoLessons)): ?>
                                    <ul id="video-playlist" class="list-unstyled">
                                        <?php $__currentLoopData = $videoLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $thumbnail = !empty($video->thumbnail_url) ? asset('storage/' . $video->thumbnail_url) : asset('storage/default_image.png');
                                            ?>
                                            <li class="video-item" id="video-<?php echo e($index); ?>" onclick="loadVideo(<?php echo e($index); ?>)" style="cursor: pointer; display: flex;  margin-bottom: 10px;">
                                                <img src="<?php echo e($thumbnail); ?>" alt="Thumbnail" width="100" height="75" style="margin-right: 10px;">
                                                <div>
                                                    <h5><?php echo e($video->title); ?></h5>
                                                    <p class="d-inline-block text-truncate" style="max-width: 340px;"><?php echo e($video->description); ?></p>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php else: ?>
                                    <p>No videos uploaded for this training program.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-8">
                        <h3 id="video-title"></h3>
                        <div id="video-container">
                            <!-- Video player will be dynamically loaded here -->
                        </div>
                        <div class="mt-5" id="quiz-container">
                            <!-- Quiz questions will be dynamically loaded here -->
                        </div>
                        <button id="submit-quiz" class="btn btn-primary" style="display: none;">Submit Answers</button>
                    </div>
                </div>

            </div>
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
<?php $__env->startSection('custom_js'); ?>
<script>

    let currentVideoIndex = 0;
    const videoLessons = <?php echo json_encode($videoLessons, 15, 512) ?>;
    const videoContainer = document.getElementById('video-container');
    const quizContainer = document.getElementById('quiz-container');
    const submitButton = document.getElementById('submit-quiz');
    let quizzes = [];

    function loadVideo(index) {
        currentVideoIndex = index;

        // Load video player
        if (videoLessons[index]) {
            document.getElementById('video-title').innerText = videoLessons[index].title;
            videoContainer.innerHTML = `
                    <video width="100%" height="400" controls id="videoPlayer-${index}">
                        <source src="<?php echo e(asset('storage/')); ?>/${videoLessons[index].video_url}" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                `;

            const videoElement = document.getElementById(`videoPlayer-${index}`);

            // Hide the quiz submit button until the video ends
            submitButton.style.display = 'none';

            // Handle video end event
            videoElement.onended = function() {
                console.log("Video finished");

                var videoLessonId = videoLessons[index].id;
                var completedAt = new Date().toISOString().slice(0, 19).replace("T", " ");

                $.ajax({
                    url: '/backend/trainings/store-training-activity',
                    method: 'POST',
                    data: {
                        user_id: <?php echo e(Auth::user()->id); ?>,
                        training_id: <?php echo e($training->id); ?>,
                        video_lesson_id: videoLessonId,
                        completed_at: completedAt
                    },
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.success) {
                            //alert('Training activity recorded!');
                            loadQuizQuestions(videoLessonId);
                        } else {
                           // alert('Failed to record the activity.');
                        }
                    },
                    error: function(xhr) {
                        //console.error(xhr.responseText);
                        //alert('An error occurred while recording the activity.');
                    }
                });
            };
        } else {
            videoContainer.innerHTML = `<p><strong>Training Completed! No more videos available.</strong></p>`;
            document.getElementById('video-title').innerText = "Training Completed";
        }
    }

    function loadQuizQuestions(videoLessonId) {
        $.ajax({
            url: '/backend/trainings/get-quiz-questions',
            method: 'GET',
            data: { video_lesson_id: videoLessonId },
            success: function(response) {
                if (response.success) {
                    displayQuiz(response.questions);
                    $('input[type="radio"]').on('change', checkAllAnswers);
                    $('#submit-quiz').prop('disabled', true).show();
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: "Failed to load quiz questions.",
                    });
                    //alert('Failed to load quiz questions.');
                    $('#submit-quiz').hide();
                }
            },
            error: function(xhr) {
                //console.error(xhr.responseText);
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: "An error occurred while loading quiz questions.",
                });
                //alert('An error occurred while loading quiz questions.');
                $('#submit-quiz').hide();
            }
        });
    }

    function displayQuiz(questions) {
        quizzes = questions;
        let html = '';
        questions.forEach((quiz, index) => {
            html += `
                    <div class="quiz">
                        <p>${index + 1}. ${quiz.question}</p>
                        ${quiz.options.map(option => `
                            <label>
                                <input type="radio" name="quiz_${quiz.id}" value="${option.id}" />
                                ${option.option}
                            </label>
                        `).join('')}
                    </div>
                `;
    });
        quizContainer.innerHTML = html;
    }

    function checkAllAnswers() {
        const totalQuestions = $('.quiz').length;
        const answeredQuestions = $('.quiz input[type="radio"]:checked').length;

        if (answeredQuestions === totalQuestions) {
            $('#submit-quiz').prop('disabled', false);
        } else {
            $('#submit-quiz').prop('disabled', true);
        }
    }

    $('#submit-quiz').on('click', function () {
        const answers = [];
        quizzes.forEach(function (quiz) {
            const selectedOption = $(`input[name="quiz_${quiz.id}"]:checked`);
            if (selectedOption.length) {
                answers.push({
                    quiz_id: quiz.id,
                    option_id: selectedOption.val(),
                });
            }
        });

        if (answers.length < quizzes.length) {
            alert('Please answer all questions.');
            return;
        }

        $.ajax({
            url: '/backend/trainings/submit-quiz-answers',
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
            },
            contentType: 'application/json',
            data: JSON.stringify({
                user_id: <?php echo e(Auth::user()->id); ?>,
                video_lesson_id: videoLessons[currentVideoIndex].id,
                answers: answers,
            }),
            success: function (data) {
                if (data.success) {
                    swal.fire(
                        'Done!',
                        'Quiz submitted successfully!',
                        'success'
                    );
                    quizContainer.innerHTML = ""; // Clear quiz container
                    submitButton.style.display = 'none'; // Hide submit button
                    loadVideo(currentVideoIndex + 1);
                    //alert('Quiz submitted successfully!');
                } else {
                    Swal.fire({
                        icon: "error",
                        title: "Oops...",
                        text: data.message || 'Failed to submit quiz.',
                    });
                    //alert(data.message || 'Failed to submit quiz.');
                }
            },
            error: function (xhr) {
                console.error('Error submitting quiz:', xhr.responseText);
                Swal.fire({
                    icon: "error",
                    title: "Oops...",
                    text: xhr.responseText || 'Failed to submit quiz.',
                });
            },
        });
    });

    $(document).ready(function() {
        loadVideo(currentVideoIndex);
    });
     

    
      
    

    
    

    
        

        
        
        
        
            
            
            
                
                
                
                
            
            
                
            
            
                
                    
                    
                    
                
                    
                
            
            
                
                
            
        
    


    
    
        
        
            
            
            
            
                
                    
                    
                    
                    

                    
                    
                
                    
                    
                
            
            
                
                
                
            
        
    


    
        
        
        
            
                        
                            
                            
            
                
                                
                                    
                                    
                                
                            
            
            
                        
         
        
    

    
    
        
        

        
        
            
        
            
        
    
    
        

        
        
            
            
                
                    
                    
                
            
        

        
            
            
        

        
        
            
            
            
                
            
            
            
                
                
                
            
            
                
                    
                
                    
                
            
            
                
            
        
    

     
     
     
     
     
     
     
         

         
         
            
                
                
            
        
         
         



         
         
     

     
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\4uv-nivzen\resources\views/admin/trainings/view.blade.php ENDPATH**/ ?>
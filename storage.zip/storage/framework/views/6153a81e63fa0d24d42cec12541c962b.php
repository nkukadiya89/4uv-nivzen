<?php $__env->startSection('content'); ?>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
        <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5"><?php echo e($title); ?></h5>
                    <!--end::Page Title-->
                </div>
                <!--end::Page Heading-->
            </div>
            <!--end::Info-->

        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Card-->
            <div class="card card-custom">
                    
                <div class="card-header">
                    <div class="card-title">
                    </div>
                    <div class="card-toolbar">
                        <!--begin::Button-->
                        <a href="<?php echo e(url('backend/permissions')); ?>" class="btn btn-warning font-weight-bolder mr-2">

                        <i class="la la-eye"></i>Permissions</a>

                        <a href="<?php echo e(url('backend/roles/create')); ?>" class="btn btn-primary float-end ">
                            <i class="la la-plus"></i>Add Role</a>
                        </a>

                        <!--end::Button-->
                    </div>
                </div>
                    
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
                    <?php endif; ?>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                                <th width="40%">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($role->id); ?></td>
                                <td><?php echo e($role->name); ?></td>
                                <td>
                                    <a href="<?php echo e(url('backend/roles/'.$role->id.'/give-permissions')); ?>" class="btn btn-warning">
                                        Add / Edit Role Permission
                                    </a>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update role')): ?>
                                    <a href="<?php echo e(url('backend/roles/'.$role->id.'/edit')); ?>" class="btn btn-success">
                                        Edit
                                    </a>
                                    <?php endif; ?>

                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete role')): ?>
                                    <a href="<?php echo e(url('backend/roles/'.$role->id.'/delete')); ?>" class="btn btn-danger mx-2">
                                        Delete
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
                
            </div>
            <!--end::Card-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
<?php $__env->startSection('custom_js'); ?>
  <script>
    $(document).ready(function() {

        <?php if(Session::has('success-message')): ?>
            toastr.info("<?php echo e(session('success-message')); ?>");
        <?php endif; ?>

        var url =  '<?php echo e(config('constants.ADMIN_URL')); ?>batches/list-ajax';
        DataTables.init('#datatable_ajax', url);
    });


  </script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\4uv-nivzen\resources\views/admin/role-permission/role/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
        <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5"><?php echo e($title); ?></h5>
                    <!--end::Page Title-->
                </div>
                <!--end::Page Heading-->
            </div>
            <!--end::Info-->

        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="p-6 flex-fill">
        <!--begin::Container-->

        <div class="card card-custom gutter-b example example-compact">
            <!--begin::Form-->
            <form class="form-horizontal" id="frmAdd" action="<?php echo e(route('user-add')); ?>">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group ">
                                <label for="firstname">First Name<span class="required">*</span></label>
                                <div>
                                    <input id="firstname" type="text" class="form-control required" name="firstname"
                                        value="<?php echo e(old('firstname')); ?>" placeholder="First Name">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group ">
                                <label for="lastname">Last Name<span class="required">*</span></label>
                                <div>
                                    <input id="lastname" type="text" class="form-control required" name="lastname"
                                        value="<?php echo e(old('lastname')); ?>" placeholder="Last Name">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="phone">Mobile No<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="phone" id="phone" class="form-control required"
                                        value="<?php echo e(old('phone')); ?>" placeholder="Phone">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="dob">Date of Birth<span class="required">*</span></label>
                                <div>
                                    <input class="form-control required" type="date" placeholder="Birth date" name="dob"
                                        value="<?php echo e(old('dob')); ?>" autocomplete="off" />
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="email">Email ID<span class="required">*</span></label>
                                <div>
                                    <input type="email" name="email" id="email" class="form-control required"
                                        value="<?php echo e(old('email')); ?>" placeholder="Email">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label  for="roles" >Roles<span class="required">*</span></label>
                            <div>

                                <select name="roles" class="form-control required"  id="user_roles" placeholder="Role">
                                    <option value="">Select Role</option>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k); ?>">
                                            <?php echo e($res); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">

                            <div class="form-group">
                                <label for="address1">Address<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="address1" id="address1" class="form-control required"
                                        value="<?php echo e(old('address1')); ?>" placeholder="Address">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="address2">Area<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="address2" id="address2" class="form-control required"
                                        value="<?php echo e(old('address2')); ?>" placeholder="Area">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">

                            <div class="form-group">
                                <label for="city">City<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="city" id="city" class="form-control required"
                                        value="<?php echo e(old('city')); ?>" placeholder="City">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="state">State<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="state" id="state" class="form-control required"
                                        value="<?php echo e(old('state')); ?>" placeholder="State">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="country">Country<span class="required">*</span></label>
                                <div>
                                    <input type="text" name="country" id="country" class="form-control required"
                                        value="<?php echo e(old('country')); ?>" placeholder="Country">
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="phone">Pincode</label>
                                <div>
                                    <input type="text" name="pincode" id="pincode" class="form-control"
                                           value="<?php echo e(old('pincode')); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-md-4 col-lg-3">
                            <div class="form-group">
                                <label for="status"> Status</label>
                                <div>
                                    <input type="checkbox"   name="status"   value="1"  data-toggle="toggle" data-on="Yes" data-off="No" checked >
                                </div>
                            </div>
                        </div>

                    </div>


                </div>
                <!-- /.card-body -->
                <div class="card-footer d-flex justify-content-end">



                    <a href="<?php echo e(route('users-manage')); ?>" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary ml-2">Submit</button>
                </div>

                <!-- /.card-footer -->
            </form>
            <!--end::Form-->
        </div>


        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>

<?php $__env->startSection('custom_js'); ?>
<script>
$('#description').summernote({
    height: 200,
});
$(document).ready(function() {

    <?php if(Session::has('success-message')): ?>
    toastr.info("<?php echo e(session('success-message')); ?>");
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\4uv-nivzen\resources\views/admin/user/add.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class=" d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
        <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5"><?php echo e($title); ?></h5>
                    <!--end::Page Title-->
                </div>
                <!--end::Page Heading-->
            </div>
            <!--end::Info-->

        </div>
    </div>
    <!--end::Subheader-->
    <!--begin::Entry-->
    <div class="p-6 flex-fill">
        <div class="card card-custom gutter-b">
            <div class="card-header align-content-center">
                <div class="card-title">
                </div>
                <div class="p-2">
                    <!--begin::Button-->
                    <a href="<?php echo e(route('users-manage')); ?>" class="btn btn-primary">
                        Back</a>
                    <!--end::Button-->
                </div>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Name</label>
                            <div>
                                <?php echo e($user->name); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Email</label>
                            <div>
                                <?php echo e($user->email); ?>


                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Roles</label>
                            <div>
                                <?php $__currentLoopData = $userRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p> <?php echo e($value); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Birth Date</label>
                            <div>
                                <?php echo e($user->dob); ?>


                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Phone</label>
                            <div>
                                <?php echo e($user->phone); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Address</label>
                            <div>
                                <?php echo e($user->address1 . ' ' . $user->address2); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">City</label>
                            <div>
                                <?php echo e($user->city); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">State</label>
                            <div>
                                <?php echo e($user->state); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-4 col-lg-3">
                        <div class="form-group">
                            <label class="customlbl">Country</label>
                            <div>
                                <?php echo e($user->country); ?>


                            </div>
                        </div>
                    </div>
                </div>


            </div>

        </div>
        <!--end::Card-->
    </div>
    <!--end::Entry-->
</div>
<?php $__env->startSection('custom_js'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\4uv-nivzen\resources\views/admin/user/user_details.blade.php ENDPATH**/ ?>
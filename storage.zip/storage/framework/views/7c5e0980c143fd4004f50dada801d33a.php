<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column flex-column-fluid" id="kt_content">
        <!-- Subheader -->
        <div class="subheader py-2 py-lg-6 subheader-solid" id="kt_subheader">
            <div class="container-fluid d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                <div class="d-flex align-items-center flex-wrap mr-1">
                    <h5 class="text-dark font-weight-bold my-1 mr-5"><?php echo e($title); ?></h5>
                </div>
            </div>
        </div>
        <!-- Main Content -->
        <div class="p-6 flex-fill">
            <div class="card card-custom gutter-b example example-compact">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form class="form-horizontal" id="frmEdit" method="POST" action="<?php echo e(route('training-edit', $training->id ?? null)); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($training)): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>
                    <div class="card-body">
                        <!-- Training Name -->
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label" for="trainingName">Training Name<span class="required">*</span></label>
                            <div class="col-lg-6">
                                <input type="text" name="name" id="trainingName" class="form-control required" placeholder="Enter training name" value="<?php echo e($training->name ?? ''); ?>" />
                            </div>
                        </div>
                        <div id="video-section">
                            <!-- Existing Videos -->
                            <?php if(isset($training->videoLessons) && count($training->videoLessons) > 0): ?>
                                <?php $__currentLoopData = $training->videoLessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videoIndex => $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="video-container mb-4 border p-3 rounded" data-video-index="<?php echo e($videoIndex); ?>">
                                        <h4 class="d-flex justify-content-between align-items-center">Video <?php echo e($videoIndex + 1); ?>

                                        <button type="button" class="btn btn-sm btn-danger" onclick="removeVideo(<?php echo e($training->id); ?>, <?php echo e($videoIndex); ?>)">Remove Video</button></h4>
                                        <input type="hidden" name="videos[<?php echo e($videoIndex); ?>][id]" value="<?php echo e($video->id); ?>">
                                        <div class="form-group row">
                                            <label class="col-lg-3 form-label">Video Title<span class="required">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="text" name="videos[<?php echo e($videoIndex); ?>][title]" class="form-control required" placeholder="Enter video title" value="<?php echo e($video->title); ?>" />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-3 form-label">Video Description</label>
                                            <div class="col-lg-6">
                                                <textarea name="videos[<?php echo e($videoIndex); ?>][description]" class="form-control" rows="3" placeholder="Enter video description"><?php echo e($video->description); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-3 form-label">Upload Video<span class="required">*</span></label>
                                            <div class="col-lg-6">
                                                <input type="file" name="videos[<?php echo e($videoIndex); ?>][video]" class="form-control" accept="video/*" />
                                                <p id="current-video">Current Video: <a href="<?php echo e(asset('storage/' . $video->video_url)); ?>" target="_blank">View Video</a></p>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-3 form-label">Upload Thumbnail</label>
                                            <div class="col-lg-6">
                                                <input type="file" name="videos[<?php echo e($videoIndex); ?>][thumbnail]" class="form-control" accept="image/*" />
                                                <?php if($video->thumbnail_url): ?>
                                                    <div class="mt-2">
                                                        <img id="current-thumbnail" src="<?php echo e(asset('storage/' . $video->thumbnail_url)); ?>" alt="Thumbnail" class="img-thumbnail" width="100"></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="mcq-section mb-4">
                                            <h5 class="d-flex justify-content-between align-items-center">Questions
                                                <button type="button" class="btn btn-sm btn-primary" onclick="addQuestion(<?php echo e($videoIndex); ?>)">Add Question</button>
                                            </h5>

                                            <?php $__currentLoopData = $video->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quizIndex => $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div id="question-container-<?php echo e($videoIndex); ?>-<?php echo e($quizIndex); ?>" class="question-container mb-4 border p-3 rounded" data-question-index="<?php echo e($quizIndex); ?>">
                                                    <div class="form-group row">
                                                        <input type="hidden" name="videos[<?php echo e($videoIndex); ?>][quizzes][<?php echo e($quizIndex); ?>][id]" value="<?php echo e($quiz->id); ?>">
                                                        <label class="col-lg-2 col-form-label">Question: <?php echo e($quizIndex + 1); ?><span class="required">*</span></label>
                                                        <div class="col-lg-7">
                                                            <input type="text" name="videos[<?php echo e($videoIndex); ?>][quizzes][<?php echo e($quizIndex); ?>][question]" class="form-control required" placeholder="Enter question" value="<?php echo e($quiz->question); ?>"  />
                                                        </div>
                                                        <div class="col-lg-3">
                                                            <button type="button" class="btn btn-sm btn-danger" onclick="removeQuestion(<?php echo e($videoIndex); ?>, <?php echo e($quizIndex); ?>)">Remove Question</button>
                                                        </div>
                                                    </div>
                                                    <?php $__currentLoopData = $quiz->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionIndex => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <div class="form-group row option-container" data-option-index="<?php echo e($optionIndex); ?>">
                                                            <input type="hidden" name="videos[<?php echo e($videoIndex); ?>][quizzes][<?php echo e($quizIndex); ?>][options][<?php echo e($optionIndex); ?>][id]" value="<?php echo e($option->id); ?>">
                                                            <label class="col-lg-2 col-form-label">Option <?php echo e($optionIndex + 1); ?>:</label>
                                                            <div class="col-lg-4">
                                                                <input type="text" name="videos[<?php echo e($videoIndex); ?>][quizzes][<?php echo e($quizIndex); ?>][options][<?php echo e($optionIndex); ?>][option]" class="form-control required" placeholder="Enter option" value="<?php echo e($option->option); ?>"  />
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <input type="radio" name="videos[<?php echo e($videoIndex); ?>][quizzes][<?php echo e($quizIndex); ?>][correct_option]" value="<?php echo e($optionIndex); ?>" <?php echo e($option->is_correct ? 'checked' : ''); ?>> Correct
                                                            </div>
                                                            <div class="col-lg-3">
                                                                <button type="button" class="btn btn-sm btn-danger" onclick="removeOption(<?php echo e($videoIndex); ?>, <?php echo e($quizIndex); ?>, <?php echo e($optionIndex); ?>)">Remove Option</button>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <button type="button" class="btn btn-sm btn-secondary" onclick="addOption(<?php echo e($videoIndex); ?>, <?php echo e($quizIndex); ?>)">Add Option</button>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <!-- Add Video Button -->
                        <button type="button" class="btn btn-success mb-4" onclick="addVideo()">Add Another Video</button>
                    </div>
                    <div class="card-footer d-flex justify-content-end">
                        <a href="<?php echo e(route('trainings-manage')); ?>" class="btn btn-secondary mr-2">Cancel</a>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
    <script>
        let videoCount = document.querySelectorAll('.video-container').length || 0;

        // Add a new video
        function addVideo() {
            const videoSection = document.getElementById('video-section');
            const newVideoIndex = videoCount++;

            const videoTemplate = `
        <div class="video-container mb-4 border p-3 rounded" data-video-index="${newVideoIndex}">
            <h4 class="d-flex justify-content-between align-items-center">Video ${newVideoIndex + 1}
            <button type="button" class="btn btn-sm btn-danger mt-3" onclick="removeVideo(null, ${newVideoIndex})">Remove Video</button>
            </h4>
            <div class="form-group row">
                <label class="col-lg-3 form-label">Video Title</label>
                <div class="col-lg-6">
                    <input type="text" name="videos[${newVideoIndex}][title]" class="form-control required" placeholder="Enter video title" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-3 form-label">Video Description</label>
                <div class="col-lg-6">
                    <textarea name="videos[${newVideoIndex}][description]" class="form-control" rows="3" placeholder="Enter video description"></textarea>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-3 form-label">Upload Video</label>
                <div class="col-lg-6">
                    <input type="file" name="videos[${newVideoIndex}][video]" class="form-control" accept="video/*" />
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-3 form-label">Upload Thumbnail</label>
                <div class="col-lg-6">
                    <input type="file" name="videos[${newVideoIndex}][thumbnail]" class="form-control" accept="image/*" />
                </div>
            </div>
            <div class="mcq-section mb-4">
                <h5 class="d-flex justify-content-between align-items-center">Questions
                <button type="button" class="btn btn-sm btn-primary" onclick="addQuestion(${newVideoIndex})">Add Question</button>
                </h5>
            </div>
        </div>
    `;

            videoSection.insertAdjacentHTML('beforeend', videoTemplate);
        }

        // Remove a video
        function removeVideo(trainingId, videoIndex) {
            const videoContainer = document.querySelector(`.video-container[data-video-index="${videoIndex}"]`);

            if (!videoContainer) {
                console.error("Video container not found!");
                return;
            }

            // Get Video ID from Hidden Input Field
            const videoIdInput = videoContainer.querySelector(`input[name="videos[${videoIndex}][id]"]`);
            const videoLessonId = videoIdInput ? videoIdInput.value : null;

            if (videoLessonId) {
                swal.fire({
                    title: 'Are you sure You want to delete this record?',
                    text: '',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then(function(result) {
                    if (result.value) {
                        $.ajax({
                            url: `/backend/training/${trainingId}/video/${videoLessonId}`,
                            type: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function (response) {
                                console.log(response.message);
                                swal.fire(
                                    'Deleted!',
                                    'Your record has been deleted.',
                                    'success'
                                );
                                videoContainer.remove(); // Remove from DOM
                            },
                            error: function (xhr) {
                                console.error("Error deleting video:", xhr.responseText);
                                swal("Error!", "Error deleting video. Please try again.", "error");
                            }
                        });

                    }
                });
            } else {
                videoContainer.remove();
            }
        }

        // Add a new question to a specific video
        function addQuestion(videoIndex) {
            const videoContainer = document.querySelector(`.video-container[data-video-index="${videoIndex}"]`);
            const mcqSection = videoContainer.querySelector('.mcq-section');
            const questionCount = videoContainer.querySelectorAll('.question-container').length || 0;

            const questionTemplate = `
        <div id="question-container-${videoIndex}-${questionCount}" class="question-container mb-4 border p-3 rounded" data-question-index="${questionCount}">
            <div class="form-group row">
                <label class="col-lg-2 col-form-label">Question: ${questionCount + 1}</label>
                <div class="col-lg-7">
                    <input type="text" name="videos[${videoIndex}][quizzes][${questionCount}][question]" class="form-control required" placeholder="Enter question"  />
                </div>
                <div class="col-lg-3">
                <button type="button" class="btn btn-sm btn-danger mt-2" onclick="removeQuestion(${videoIndex}, ${questionCount})">Remove Question</button>
                </div>
            </div>
            <div class="option-section">
                <div class="form-group row option-container" data-option-index="0">
                    <label class="col-lg-2 col-form-label">Option 1:</label>
                    <div class="col-lg-4">
                        <input type="text" name="videos[${videoIndex}][quizzes][${questionCount}][options][0][option]" class="form-control required" placeholder="Enter option"  />
                    </div>
                    <div class="col-lg-3">
                        <input type="radio" name="videos[${videoIndex}][quizzes][${questionCount}][correct_option]" value="0"> Correct
                    </div>
                    <div class="col-lg-3">
              <button type="button" class="btn btn-sm btn-danger" onclick="removeOption( ${videoIndex}, ${questionCount}, 0)">Remove Option</button>
            </div>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-secondary" onclick="addOption(${videoIndex}, ${questionCount})">Add Option</button>

        </div>
    `;

            mcqSection.insertAdjacentHTML('beforeend', questionTemplate);
        }

        // Remove a question from a specific video
        function removeQuestion(videoIndex, questionIndex) {
            const questionContainer = document.getElementById(`question-container-${videoIndex}-${questionIndex}`);

            if (!questionContainer) {
                console.error("Question container not found!");
                return;
            }

            // Get Question ID
            const questionIdInput = questionContainer.querySelector(`input[name="videos[${videoIndex}][quizzes][${questionIndex}][id]"]`);
            const questionId = questionIdInput ? questionIdInput.value : null;

            if (questionId) {
                swal.fire({
                    title: 'Are you sure you want to delete this question and all its options?',
                    text: '',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then(function(result) {
                    if (result.value) {
                        $.ajax({
                            url: `/backend/delete-quiz/${questionId}`,
                            type: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function (response) {
                                swal.fire(
                                    'Deleted!',
                                    'Your record has been deleted.',
                                    'success'
                                );
                                questionContainer.remove(); // Remove from DOM
                            },
                            error: function (xhr) {
                                console.error("Error deleting question:", xhr.responseText);
                                swal("Error!", "Error deleting question. Please try again.", "error");
                            }
                        });

                    }
                });
            } else {
                questionContainer.remove();
            }
        }

        // Add a new option to a specific question
        function addOption(videoIndex, questionIndex) {


            const questionContainer = document.getElementById(`question-container-${videoIndex}-${questionIndex}`);

            // Check if the question container is found
            if (!questionContainer) {
                console.error("Question container not found!");
                return;
            }

            // Find the option section within the question container
            let optionSection = questionContainer.querySelector('.option-section');

            // If option section is not found, create and append it
            if (!optionSection) {
                optionSection = document.createElement('div');
                optionSection.classList.add('option-section');
                questionContainer.appendChild(optionSection);
            }

            const optionCount = questionContainer.querySelectorAll('.option-container').length || 0;

            const optionTemplate = `
        <div class="form-group row option-container" data-option-index="${optionCount}">
            <label class="col-lg-2 col-form-label">Option ${optionCount + 1}:</label>
            <div class="col-lg-4">
                <input type="text" name="videos[${videoIndex}][quizzes][${questionIndex}][options][${optionCount}][option]" class="form-control required" placeholder="Enter option"  />
            </div>
            <div class="col-lg-3">
                <input type="radio" name="videos[${videoIndex}][quizzes][${questionIndex}][correct_option]" value="${optionCount}"> Correct
            </div>
            <div class="col-lg-3">
              <button type="button" class="btn btn-sm btn-danger" onclick="removeOption(${videoIndex}, ${questionIndex}, ${optionCount})">Remove Option</button>
            </div>
        </div>
    `;

            // Insert the new option into the option section
            optionSection.insertAdjacentHTML('beforeend', optionTemplate);
        }

        // Remove an option (optional - not mandatory)
        function removeOption(videoIndex, questionIndex, optionIndex) {
            let optionContainer = $(`.option-container[data-option-index="${optionIndex}"]`);

            if (optionContainer.length === 0) {
                console.error("Error: Could not find option container.");
                return;
            }

            // Find the hidden input inside the optionContainer
            let optionInput = optionContainer.find(`input[name^="videos[${videoIndex}][quizzes][${questionIndex}][options][${optionIndex}][id]"]`);

            if (optionInput.length === 0) {
                console.warn("Hidden input not found for option ID.");
            }

            let optionId = optionInput.val(); // Get option ID from the hidden input

            if (optionId) {
                swal.fire({
                    title: 'Are you sure you want to delete this answer?',
                    text: '',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel',
                    reverseButtons: true
                }).then(function(result) {
                    if (result.value) {
                        $.ajax({
                            url: `/backend/delete-quiz-option/${optionId}`,
                            type: 'DELETE',
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                            },
                            success: function (response) {
                                swal.fire(
                                    'Deleted!',
                                    'Your record has been deleted.',
                                    'success'
                                );
                                optionContainer.remove(); // Remove from DOM
                            },
                            error: function (xhr) {
                                swal("Error!", "Error deleting answer. Please try again.", "error");
                            }
                        });

                    }
                });
            } else {
                optionContainer.remove(); // Remove from DOM if not saved in the database
            }
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\4uv-nivzen\resources\views/admin/trainings/edit.blade.php ENDPATH**/ ?>